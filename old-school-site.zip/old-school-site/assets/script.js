// =========================================================
// OLD SCHOOL — shared prototype interactions (demo only)
// =========================================================

document.addEventListener('DOMContentLoaded', () => {

  /* ---- Scroll reveal ---- */
  const revealEls = document.querySelectorAll('.reveal');
  if (revealEls.length){
    const io = new IntersectionObserver((entries)=>{
      entries.forEach(e=>{ if(e.isIntersecting){ e.target.classList.add('in'); io.unobserve(e.target); } });
    }, {threshold:0.12});
    revealEls.forEach(el=>io.observe(el));
  }

  /* ---- Burger / mobile drawer ---- */
  const burger = document.querySelector('.burger');
  const drawer = document.querySelector('.mobile-drawer');
  if (burger && drawer){
    burger.addEventListener('click', ()=>{
      drawer.classList.toggle('open');
    });
    drawer.querySelectorAll('a').forEach(a=>{
      a.addEventListener('click', ()=> drawer.classList.remove('open'));
    });
  }

  /* ---- Lang switch (visual only) ---- */
  document.querySelectorAll('.lang-switch').forEach(group=>{
    group.querySelectorAll('button').forEach(btn=>{
      btn.addEventListener('click', ()=>{
        group.querySelectorAll('button').forEach(b=>b.classList.remove('active'));
        btn.classList.add('active');
      });
    });
  });

  /* ---- Generic filter button groups (visual toggle) ---- */
  document.querySelectorAll('[data-filter-group]').forEach(group=>{
    const buttons = group.querySelectorAll('.filter-btn');
    buttons.forEach(btn=>{
      btn.addEventListener('click', ()=>{
        buttons.forEach(b=>b.classList.remove('active'));
        btn.classList.add('active');
        applyScheduleFilters();
      });
    });
  });

  /* ---- Schedule filtering (discipline + level) on grafik page ---- */
  function applyScheduleFilters(){
    const discGroup = document.querySelector('[data-filter-group="discipline"]');
    const lvlGroup = document.querySelector('[data-filter-group="level"]');
    if (!discGroup) return;
    const disc = discGroup.querySelector('.active')?.dataset.value || 'all';
    const lvl = lvlGroup ? (lvlGroup.querySelector('.active')?.dataset.value || 'all') : 'all';

    document.querySelectorAll('[data-row]').forEach(row=>{
      const rd = row.dataset.discipline;
      const rl = row.dataset.level;
      const matchDisc = disc === 'all' || rd === disc;
      const matchLvl = lvl === 'all' || rl === lvl;
      row.classList.toggle('hidden-row', !(matchDisc && matchLvl));
    });
  }
  applyScheduleFilters();

  /* ---- FAQ accordion ---- */
  document.querySelectorAll('.faq-item').forEach(item=>{
    const q = item.querySelector('.faq-q');
    if (!q) return;
    q.addEventListener('click', ()=>{
      const wasOpen = item.classList.contains('open');
      item.parentElement.querySelectorAll('.faq-item').forEach(i=>i.classList.remove('open'));
      if (!wasOpen) item.classList.add('open');
    });
  });

  /* ---- Modal (booking form) ---- */
  const modalOverlay = document.getElementById('booking-modal');
  const modalTriggers = document.querySelectorAll('[data-open-modal]');
  const modalClose = document.querySelector('.modal-close');
  const modalForm = document.getElementById('booking-form');
  const modalSuccess = document.querySelector('.modal-success');
  const modalSelectField = document.getElementById('modal-zajecia');

  function openModal(prefill){
    if (!modalOverlay) return;
    modalOverlay.classList.add('open');
    document.body.style.overflow = 'hidden';
    if (modalForm) modalForm.style.display = 'flex';
    if (modalSuccess) modalSuccess.classList.remove('show');
    if (prefill && modalSelectField){
      modalSelectField.value = prefill;
    }
  }
  function closeModal(){
    if (!modalOverlay) return;
    modalOverlay.classList.remove('open');
    document.body.style.overflow = '';
  }
  modalTriggers.forEach(btn=>{
    btn.addEventListener('click', (e)=>{
      e.preventDefault();
      openModal(btn.dataset.prefill);
    });
  });
  if (modalClose) modalClose.addEventListener('click', closeModal);
  if (modalOverlay){
    modalOverlay.addEventListener('click', (e)=>{ if (e.target === modalOverlay) closeModal(); });
  }
  if (modalForm){
    modalForm.addEventListener('submit', (e)=>{
      e.preventDefault();
      modalForm.style.display = 'none';
      if (modalSuccess) modalSuccess.classList.add('show');
    });
  }

  /* ---- Toast helper ---- */
  window.showToast = function(msg){
    let toast = document.querySelector('.toast');
    if (!toast){
      toast = document.createElement('div');
      toast.className = 'toast';
      document.body.appendChild(toast);
    }
    toast.textContent = msg;
    toast.classList.add('show');
    clearTimeout(window.__toastTimer);
    window.__toastTimer = setTimeout(()=> toast.classList.remove('show'), 3200);
  };

  /* ---- Product gallery thumbs ---- */
  const mainImg = document.querySelector('.product-gallery-main img');
  document.querySelectorAll('.product-thumbs button').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      document.querySelectorAll('.product-thumbs button').forEach(b=>b.classList.remove('active'));
      btn.classList.add('active');
      if (mainImg) mainImg.src = btn.querySelector('img').src;
    });
  });

  /* ---- Product variant selection ---- */
  document.querySelectorAll('.variant-group').forEach(group=>{
    const opts = group.querySelectorAll('.variant-btn');
    opts.forEach(btn=>{
      btn.addEventListener('click', ()=>{
        opts.forEach(b=>b.classList.remove('active'));
        btn.classList.add('active');
      });
    });
  });

  /* ---- Add to cart (demo) ---- */
  document.querySelectorAll('[data-add-to-cart]').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      window.showToast('Sklep zostanie uruchomiony wkrótce.');
    });
  });

  /* ---- Stub links (disciplines/trainers/products without full pages) ---- */
  document.querySelectorAll('[data-stub-link]').forEach(el=>{
    el.addEventListener('click', (e)=>{
      e.preventDefault();
      window.showToast('Ta podstrona pojawi się w pełnej wersji serwisu.');
    });
  });

});
